import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Panel extends JPanel implements ActionListener {

    static final int SCREEN_WIDTH = 500;
    static final int SCREEN_HEIGHT = 300;
    static final int UNIT_SIZE = 25;
    static final private String myId = "tlsgndi";
    static final private String myPassword = "tlsgndi5133";
    Components logInComponents = new Components();
    JTextField inputId = logInComponents.myTextField(UNIT_SIZE*8, UNIT_SIZE*5, UNIT_SIZE*5, UNIT_SIZE*1);
    JTextField inputPassword = logInComponents.myPasswordField(UNIT_SIZE*8, UNIT_SIZE*7, UNIT_SIZE*5, UNIT_SIZE*1);
    JButton logInButton = logInComponents.myButton("LogIn", UNIT_SIZE*9, UNIT_SIZE*9, UNIT_SIZE*4, UNIT_SIZE*1);
    JButton signUpButton = logInComponents.myButton("SignUp", UNIT_SIZE*9, UNIT_SIZE*10, UNIT_SIZE*4, UNIT_SIZE*1);

    Panel(){
        this.setLayout(null);
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.setBackground(new Color(121, 255, 121));
        this.setFocusable(true);
        //this.addKeyListener(new MyKeyAdapter());

        addLogInComponents();

    }
    public void addLogInComponents(){
        this.add(logInComponents.myText("User Id:", UNIT_SIZE*5, UNIT_SIZE*5, UNIT_SIZE*5, UNIT_SIZE*1));
        this.add(logInComponents.myText("Password:", UNIT_SIZE*5, UNIT_SIZE*7, UNIT_SIZE*5, UNIT_SIZE*1));
        this.add(inputId);
        this.add(inputPassword);
        this.add(logInButton);
        this.add(signUpButton);
        logInButton.addActionListener(this);
        signUpButton.addActionListener(this);
    }
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }
    public void draw(Graphics g){
        drawLine(g);
    }
    public void drawLine(Graphics g) {
        for(int i=0; i<SCREEN_WIDTH/UNIT_SIZE; i++) {
            g.drawLine(0, i*UNIT_SIZE, SCREEN_WIDTH, i*UNIT_SIZE);
            g.drawLine(i*UNIT_SIZE, 0, i*UNIT_SIZE,  SCREEN_HEIGHT);
        }
    }
    public boolean checkAccount(String id, String password){
        if(myId.equals(id) && myPassword.equals(password)) return true;
        else return false;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == logInButton){
            if(checkAccount(inputId.getText(), inputPassword.getText())) System.out.println("Log in succeeded");
            else System.out.println("Log in failed");
        }
        if(e.getSource() == signUpButton){
            System.out.println("paa");
        }
    }
/*
    public class MyKeyAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {

        }
    }
 */
}
