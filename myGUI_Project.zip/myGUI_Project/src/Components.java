import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Components implements ActionListener {
    Components(){

    }
    public JLabel myText(String text, int x, int y, int width, int height){
        JLabel myLabel = new JLabel();
        myLabel.setText(text);
        myLabel.setBounds(x, y, width, height);
        return myLabel;
    }

    public JTextField myTextField(int x, int y, int width, int height){
        JTextField myTextField = new JTextField();
        myTextField.setBounds(x, y, width, height);
        return myTextField;
    }

    public JPasswordField myPasswordField(int x, int y, int width, int height){
        JPasswordField myPasswordField = new JPasswordField();
        myPasswordField.setBounds(x, y, width, height);
        return myPasswordField;
    }

    public JButton myButton(String text, int x, int y, int width, int height){
        JButton myButton = new JButton();
        myButton.setText(text);
        myButton.setBounds(x, y, width, height);
        return myButton;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }
}
